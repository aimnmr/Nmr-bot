
# بوت Telegram باستخدام Telethon

تم تعديل هذا المشروع ليكون خاص بك. البوت مرتبط بالحساب @TheKingNmr ويستخدم Telethon.

## المتطلبات

- حساب على [Heroku](https://heroku.com/)
- Python 3.10 أو أعلى
- Git

---

## خطوات الرفع على Heroku

### 1. فك الضغط

بعد تحميل الملف `nmr_telegram_bot_ready.zip`، فك الضغط عنه على جهازك.

### 2. افتح الطرفية (Terminal)

افتح نافذة الطرفية داخل مجلد المشروع.

### 3. تسجيل الدخول إلى Heroku

```bash
heroku login
```

### 4. تهيئة Git داخل المشروع

```bash
git init
```

### 5. إنشاء تطبيق جديد على Heroku

```bash
heroku create your-app-name
```

> غيّر `your-app-name` إلى اسم التطبيق الذي تريده.

### 6. إضافة المتغيرات البيئية

```bash
heroku config:set API_ID=25978936 API_HASH=cf754dc655df0e7deff36732dbfff074 BOT_TOKEN=8010574818:AAHkzc02dQbXtDnAQD5emA2ekUXHImACPIY DEVELOPER_ID=5578660820
```

### 7. رفع الملفات إلى Heroku

```bash
git add .
git commit -m "first commit"
git push heroku master
```

---

## تشغيل البوت تلقائيًا

إذا تم إعداد `Procfile` بشكل صحيح (وهو مرفق في المشروع)، سيتم تشغيل البوت تلقائيًا بعد النشر.

## الدعم والتطوير

المطور: [@TheKingNmr](https://t.me/TheKingNmr)

